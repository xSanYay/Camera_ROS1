# navbot_hardware
YouTube Autonomous Robot Series Code Repository. 
A differential drive robot controller with Arduino Mega and DC motors with encoders. Uses 2 PID controllers

### Usage

Download the code and flash the Arduino with the .ino files provided. Follow the video for more instructions.

([YouTube Video Link](https://www.youtube.com/watch?v=n9yU7u55zGg))
